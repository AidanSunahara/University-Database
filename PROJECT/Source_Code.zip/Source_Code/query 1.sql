SELECT Classroom, meeting_days, beg_time, end_time
FROM Professor p, Section s
WHERE p.SSN = 2378487 AND p.SSN = s.SSN
